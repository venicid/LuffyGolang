// +build amd64 arm64 ppc64 ppc64le

package fasthttp

const (
	maxHexIntChars = 15
)
